Print bottom down, 15% infill or greater
Suggest using supports
Installs with standard Mlok hardware
